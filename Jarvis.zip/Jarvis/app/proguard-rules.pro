# Nessuna regola particolare: l'app non usa reflection né librerie che la richiedano.
