package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.provider.Settings
import java.text.Normalizer
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** App avviabile installata sul dispositivo. */
data class AppEntry(val label: String, val packageName: String, val activity: String)

enum class UiAction { NONE, CLEAR_CHAT, STOP_SPEAKING }

/** Risultato di un comando: testo da mostrare/pronunciare (può essere vuoto) + azione UI. */
data class Outcome(val reply: String, val action: UiAction = UiAction.NONE)

private val accentRegex = Regex("\\p{M}+")
private val nonAlnumRegex = Regex("[^a-z0-9]+")

/** minuscolo, senza accenti né punteggiatura: "Che ora è?" -> "che ora e". */
fun normalize(s: String): String {
    val lower = s.lowercase(Locale.ITALIAN)
    val decomposed = Normalizer.normalize(lower, Normalizer.Form.NFD)
    return nonAlnumRegex.replace(accentRegex.replace(decomposed, ""), " ").trim()
}

fun greetingWord(): String {
    val h = LocalTime.now().hour
    return when (h) {
        in 5..12 -> "Buongiorno"
        in 13..17 -> "Buon pomeriggio"
        else -> "Buonasera"
    }
}

/**
 * Parser locale dei comandi in italiano. Tutto ciò che è comando di sistema (apri app, ora,
 * data, note, stop, pulisci chat) si risolve qui, senza rete e senza latenza.
 * Solo il resto viene passato al connettore IA (se configurato).
 */
class CommandExecutor(
    context: Context,
    private val prefs: Prefs,
    private val ai: AiClient
) {
    private val app = context.applicationContext
    private val pm = app.packageManager

    @Volatile
    private var cache: List<AppEntry>? = null

    private sealed interface Pending {
        data class Choose(val options: List<AppEntry>) : Pending
        data object Note : Pending
        data object AskApp : Pending
    }

    private var pending: Pending? = null

    // ------------------------------------------------------------------ app installate

    @Synchronized
    fun installedApps(force: Boolean = false): List<AppEntry> {
        if (!force) cache?.let { return it }
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(intent, 0)
            .map { AppEntry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name) }
            .filter { it.packageName != app.packageName }
            .distinctBy { it.packageName + "/" + it.activity }
            .sortedBy { it.label.lowercase(Locale.ITALIAN) }
        cache = list
        return list
    }

    fun launch(a: AppEntry): Outcome = try {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(a.packageName, a.activity)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        app.startActivity(i)
        Outcome(listOf("Apro ${a.label}.", "Subito. Avvio ${a.label}.", "Certamente. ${a.label} in avvio.").random())
    } catch (e: Exception) {
        Outcome("Non riesco ad avviare ${a.label}.")
    }

    // ------------------------------------------------------------------ esecuzione

    suspend fun execute(raw: String, history: List<Pair<String, String>>): Outcome {
        val text = raw.trim()
        var n = normalize(text)
        if (n.isEmpty()) return Outcome("")

        resolvePending(text, n)?.let { return it }

        n = wakeRegex.replace(n, "").trim()
        if (n.isEmpty()) return Outcome("Mi dica.")
        val cleanRaw = wakeRawRegex.replace(text, "").trim()

        if (stopRegex.matches(n)) return Outcome("", UiAction.STOP_SPEAKING)

        if (clearNotesRegex.containsMatchIn(n)) {
            prefs.notes = emptyList()
            return Outcome("Note eliminate.")
        }
        if (clearChatRegex.containsMatchIn(n)) return Outcome("Cronologia cancellata.", UiAction.CLEAR_CHAT)
        if (readNotesRegex.containsMatchIn(n)) return Outcome(readNotes())

        val first = n.substringBefore(' ')
        if (first in openVerbs) return openCommand(n.substringAfter(' ', ""))
        if (n.startsWith("fai partire ")) return openCommand(n.removePrefix("fai partire "))

        if (timeRegex.containsMatchIn(n)) return Outcome(timeReply())
        if (dateRegex.containsMatchIn(n)) {
            val d = LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE d MMMM yyyy", Locale.ITALIAN))
            return Outcome("Oggi è $d.")
        }

        noteRegex.find(cleanRaw)?.let { return saveOrAsk(it.groupValues[1]) }

        if (helpRegex.matches(n)) {
            return Outcome("Posso aprire le sue app, dirle ora e data, prendere note e, se collega un'IA, conversare.")
        }
        if (greetRegex.matches(n)) return Outcome("${greetingWord()}. Come posso esserle utile?")
        if (thanksRegex.matches(n)) return Outcome("Prego.")

        // Nessun comando locale: conversazione tramite IA, se configurata.
        if (!ai.isConfigured()) {
            return Outcome("Non ho un comando per questo. Può collegare un'IA dalle impostazioni, oppure dire «Apri» e il nome di un'app.")
        }
        return try {
            Outcome(ai.chat(text, history))
        } catch (e: Exception) {
            Outcome("Il servizio IA non è raggiungibile (${e.message ?: "errore"}).")
        }
    }

    // ------------------------------------------------------------------ pending (conversazione a più passi)

    private fun resolvePending(raw: String, n: String): Outcome? {
        val p = pending ?: return null
        pending = null
        return when (p) {
            Pending.Note ->
                if (isCancel(n)) Outcome("Va bene, annullato.") else saveNote(raw)

            Pending.AskApp ->
                if (isCancel(n)) Outcome("Come desidera.") else openByName(cleanName(n))

            is Pending.Choose -> {
                val words = n.split(' ')
                val idx = when {
                    words.any { it in firstWords } -> 0
                    words.any { it in secondWords } -> 1
                    words.any { it in thirdWords } -> 2
                    else -> null
                }
                val chosen = idx?.let { p.options.getOrNull(it) }
                    ?: p.options.firstOrNull {
                        val l = normalize(it.label)
                        n.contains(l) || (n.length >= 3 && l.contains(n))
                    }
                when {
                    chosen != null -> launch(chosen)
                    isCancel(n) -> Outcome("Come desidera.")
                    else -> null // nuovo comando: lo elabora normalmente
                }
            }
        }
    }

    private fun isCancel(n: String) =
        n == "no" || n == "niente" || n.startsWith("annulla") || n.startsWith("lascia stare") || n.startsWith("non importa")

    // ------------------------------------------------------------------ apertura app

    private fun openCommand(rest: String): Outcome {
        val name = cleanName(rest)
        if (name.isEmpty()) {
            pending = Pending.AskApp
            return Outcome("Quale app desidera aprire?")
        }
        return openByName(name)
    }

    private fun cleanName(s: String): String {
        val toks = s.trim().split(' ').filter { it.isNotEmpty() }.toMutableList()
        while (toks.isNotEmpty() && toks.first() in fillers) toks.removeAt(0)
        return trailingRegex.replace(toks.joinToString(" "), "").trim()
    }

    private fun openByName(name: String): Outcome {
        if (name.isEmpty()) return Outcome("Quale app desidera aprire?")

        systemShortcuts[name]?.let { (action, label) ->
            return try {
                app.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Outcome("Apro $label.")
            } catch (e: Exception) {
                Outcome("Non riesco ad aprire $label.")
            }
        }

        var ranked = rank(name, installedApps())
        if ((ranked.firstOrNull()?.second ?: 0) < 60) {
            ranked = rank(name, installedApps(force = true)) // forse appena installata
        }
        val best = ranked.firstOrNull() ?: return Outcome("Non trovo alcuna app chiamata «$name».")

        val close = ranked.filter { it.second >= best.second - 5 }.take(3)
        if (best.second >= 100 || close.size == 1) return launch(best.first)

        pending = Pending.Choose(close.map { it.first })
        val labels = close.map { it.first.label }
        val question = if (labels.size == 2) {
            "Intende ${labels[0]} o ${labels[1]}?"
        } else {
            "Intende ${labels[0]}, ${labels[1]} o ${labels[2]}?"
        }
        return Outcome(question)
    }

    /** Ordina le app per somiglianza col nome pronunciato (un solo risultato per pacchetto). */
    private fun rank(q: String, apps: List<AppEntry>): List<Pair<AppEntry, Int>> {
        val keys = aliases[q].orEmpty()
        val qc = q.replace(" ", "")
        val scored = apps.map { a ->
            val l = normalize(a.label)
            val lc = l.replace(" ", "")
            val p = a.packageName.lowercase(Locale.ROOT)
            var s = when {
                lc == qc -> 100
                qc.length >= 3 && lc.startsWith(qc) -> 90
                qc.length >= 3 && l.contains(q) -> 75
                lc.length >= 3 && q.contains(l) -> 70
                qc.length >= 4 && p.contains(qc) -> 60
                tokensMatch(q, l) -> 65
                qc.length >= 5 && lc.length >= 5 &&
                    levenshtein(lc, qc) <= (if (qc.length >= 8) 2 else 1) -> 85
                else -> 0
            }
            if (keys.any { k -> l.contains(k) || p.contains(k) }) s = maxOf(s, 80)
            a to s
        }.filter { it.second > 0 }

        return scored
            .groupBy { it.first.packageName }
            .map { (_, group) -> group.maxByOrNull { it.second }!! }
            .sortedByDescending { it.second }
    }

    private fun tokensMatch(q: String, label: String): Boolean {
        val qt = q.split(' ').filter { it.length >= 3 }
        if (qt.isEmpty()) return false
        val lt = label.split(' ')
        return qt.all { t -> lt.any { it.startsWith(t) } }
    }

    private fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            prev = cur
        }
        return prev[b.length]
    }

    // ------------------------------------------------------------------ ora, note

    private fun timeReply(): String {
        val t = LocalTime.now()
        val h = t.hour
        val m = t.minute
        val verb = if (h == 0 || h == 1 || h == 12) "È" else "Sono"
        val hs = when (h) {
            0 -> "mezzanotte"
            12 -> "mezzogiorno"
            1 -> "l'una"
            else -> "le $h"
        }
        val tail = when {
            m != 0 -> " e $m"
            h == 0 || h == 12 -> ""
            else -> " in punto"
        }
        return "$verb $hs$tail."
    }

    private fun saveOrAsk(content: String): Outcome {
        if (content.isBlank()) {
            pending = Pending.Note
            return Outcome("Cosa devo annotare?")
        }
        return saveNote(content)
    }

    private fun saveNote(content: String): Outcome {
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM HH:mm"))
        val body = content.trim().replaceFirstChar { it.uppercase() }
        prefs.notes = prefs.notes + "$stamp · $body"
        return Outcome("Annotato.")
    }

    private fun readNotes(): String {
        val notes = prefs.notes
        return when (notes.size) {
            0 -> "Non ci sono note salvate."
            1 -> "Ha una nota: ${notes[0].substringAfter(" · ")}."
            else -> "Ha ${notes.size} note. Le più recenti: " +
                notes.takeLast(3).reversed().joinToString(". ") { it.substringAfter(" · ") } + "."
        }
    }

    // ------------------------------------------------------------------ tabelle e regex

    private companion object {
        val wakeRegex = Regex("^((ehi|ok|ciao|hey) )?jarvis ?")
        val wakeRawRegex = Regex("^((ehi|ok|ciao|hey) )?jarvis[,.:!]?\\s*", RegexOption.IGNORE_CASE)

        val stopRegex = Regex("^(smetti( di parlare)?|basta|silenzio|zitto|stai zitto|fermati|stop|taci)( .*)?$")
        val clearChatRegex = Regex("^(pulisci|cancella|svuota|elimina|resetta)\\b.*\\b(chat|cronologia|conversazione)\\b")
        val clearNotesRegex = Regex("^(cancella|elimina|svuota)\\b.*\\b(note|promemoria|appunti)\\b")
        val readNotesRegex = Regex("^(leggi|mostra|elenca|dimmi|fammi vedere)\\b.*\\b(note|promemoria|appunti)\\b")
        val timeRegex = Regex("(che ore|che ora|dimmi l ora|ora attuale)")
        val dateRegex = Regex("(che giorno|che data|data di oggi|quanti ne abbiamo)")
        val helpRegex = Regex("^(aiuto|cosa sai fare|che cosa sai fare|cosa puoi fare|che puoi fare)$")
        val greetRegex = Regex("^(ciao|salve|buongiorno|buonasera|buon pomeriggio|ehi|ehila|ci sei)$")
        val thanksRegex = Regex("^(grazie|ti ringrazio|ok grazie|grazie mille)( .*)?$")
        val trailingRegex = Regex("\\s+(per favore|per piacere|grazie|adesso|subito)$")

        val noteRegex = Regex(
            "^(?:(?:imposta|crea|aggiungi|fai)(?:mi)?\\s+(?:un|una|un')?\\s*)?" +
                "(?:ricordami(?:\\s+(?:di|che))?|promemoria(?:\\s+(?:di|che|per))?|" +
                "nota(?:\\s+(?:di|che))?|prendi\\s+nota(?:\\s+(?:di|che))?|appunta(?:\\s+che)?|" +
                "scrivi\\s+(?:una\\s+)?nota(?:\\s+(?:di|che))?)\\s*[:,]?\\s*(.*)$",
            RegexOption.IGNORE_CASE
        )

        val openVerbs = setOf("apri", "aprimi", "avvia", "avviami", "lancia", "lanciami")
        val fillers = setOf(
            "l", "lo", "la", "il", "i", "gli", "le", "un", "una", "app", "applicazione",
            "di", "del", "della", "dello", "dei", "su", "per", "favore", "mi"
        )
        val firstWords = setOf("primo", "prima", "uno", "1")
        val secondWords = setOf("secondo", "seconda", "due", "2")
        val thirdWords = setOf("terzo", "terza", "tre", "3")

        /** Scorciatoie di sistema che non dipendono da app installate. */
        val systemShortcuts: Map<String, Pair<String, String>> = mapOf(
            "impostazioni" to (Settings.ACTION_SETTINGS to "Impostazioni"),
            "impostazioni di sistema" to (Settings.ACTION_SETTINGS to "Impostazioni"),
            "settings" to (Settings.ACTION_SETTINGS to "Impostazioni"),
            "wifi" to (Settings.ACTION_WIFI_SETTINGS to "le impostazioni Wi-Fi"),
            "wi fi" to (Settings.ACTION_WIFI_SETTINGS to "le impostazioni Wi-Fi"),
            "impostazioni wifi" to (Settings.ACTION_WIFI_SETTINGS to "le impostazioni Wi-Fi"),
            "impostazioni wi fi" to (Settings.ACTION_WIFI_SETTINGS to "le impostazioni Wi-Fi"),
            "bluetooth" to (Settings.ACTION_BLUETOOTH_SETTINGS to "le impostazioni Bluetooth"),
            "impostazioni bluetooth" to (Settings.ACTION_BLUETOOTH_SETTINGS to "le impostazioni Bluetooth"),
            "display" to (Settings.ACTION_DISPLAY_SETTINGS to "le impostazioni dello schermo"),
            "impostazioni schermo" to (Settings.ACTION_DISPLAY_SETTINGS to "le impostazioni dello schermo")
        )

        /** Alias italiani/comuni -> parole chiave cercate in etichetta o nome pacchetto. */
        val aliases: Map<String, List<String>> = mapOf(
            "galleria" to listOf("gallery", "galleria", "photos"),
            "foto" to listOf("photos", "gallery", "galleria"),
            "fotocamera" to listOf("camera", "fotocamera"),
            "camera" to listOf("camera", "fotocamera"),
            "browser" to listOf("chrome", "firefox", "browser"),
            "internet" to listOf("chrome", "firefox", "browser"),
            "google chrome" to listOf("chrome"),
            "mappe" to listOf("maps", "mappe"),
            "telefono" to listOf("dialer", "telefono"),
            "contatti" to listOf("contacts", "contatti"),
            "rubrica" to listOf("contacts", "contatti"),
            "messaggi" to listOf("messaging", "messages", "messaggi"),
            "orologio" to listOf("clock", "orologio"),
            "sveglia" to listOf("clock", "orologio"),
            "calcolatrice" to listOf("calculator", "calcolatrice"),
            "calendario" to listOf("calendar", "calendario"),
            "file" to listOf("files", "fileexplorer", "filemanager", "gestione file"),
            "file manager" to listOf("files", "fileexplorer", "filemanager", "gestione file"),
            "musica" to listOf("music", "musica", "spotify"),
            "posta" to listOf("gmail", "mail", "posta"),
            "email" to listOf("gmail", "mail", "posta"),
            "mail" to listOf("gmail", "mail", "posta"),
            "play store" to listOf("vending", "play store"),
            "store" to listOf("vending", "play store"),
            "note" to listOf("notes", "keep", "note"),
            "meteo" to listOf("weather", "meteo")
        )
    }
}
