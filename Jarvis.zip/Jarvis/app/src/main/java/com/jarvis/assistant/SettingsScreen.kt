package com.jarvis.assistant

import android.content.Intent
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

@Composable
fun SettingsScreen(
    prefs: Prefs,
    apps: List<AppEntry>,
    ttsProblem: String?,
    onBack: () -> Unit,
    onPrefsChanged: () -> Unit,
    onTestVoice: () -> Unit,
    onOpenApp: (AppEntry) -> Unit,
    onRefreshApps: () -> Unit
) {
    val context = LocalContext.current

    var rate by remember { mutableFloatStateOf(prefs.ttsRate) }
    var pitch by remember { mutableFloatStateOf(prefs.ttsPitch) }
    var speak by remember { mutableStateOf(prefs.speakReplies) }
    var conversation by remember { mutableStateOf(prefs.conversationMode) }
    var listenOnLaunch by remember { mutableStateOf(prefs.listenOnLaunch) }
    var endpoint by remember { mutableStateOf(prefs.aiEndpoint) }
    var key by remember { mutableStateOf(prefs.aiKey) }
    var model by remember { mutableStateOf(prefs.aiModel) }
    var noteCount by remember { mutableIntStateOf(prefs.notes.size) }
    var filter by remember { mutableStateOf("") }

    val filtered = remember(apps, filter) {
        val f = normalize(filter)
        if (f.isEmpty()) apps else apps.filter {
            normalize(it.label).contains(f) || it.packageName.contains(f, ignoreCase = true)
        }
    }

    fun tryStart(intent: Intent) {
        try {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            // impostazione non disponibile su questo dispositivo
        }
    }

    Box(Modifier.fillMaxSize().background(Bg).safeDrawingPadding(), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = 720.dp).fillMaxHeight()) {
            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Indietro", tint = Cyan)
                }
                Text(
                    "IMPOSTAZIONI",
                    color = Cyan,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 3.sp,
                    fontSize = 18.sp
                )
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ---------------- voce
                item { SectionTitle("Voce") }
                item {
                    SwitchRow("Risposte parlate", "Jarvis legge ad alta voce le risposte", speak) {
                        speak = it; prefs.speakReplies = it
                    }
                }
                item {
                    Column {
                        Text("Velocità: ${"%.2f".format(Locale.ITALIAN, rate)}×", color = TextMain)
                        Slider(
                            value = rate,
                            onValueChange = { rate = it },
                            onValueChangeFinished = { prefs.ttsRate = rate; onPrefsChanged() },
                            valueRange = 0.5f..2.0f
                        )
                    }
                }
                item {
                    Column {
                        Text("Tono: ${"%.2f".format(Locale.ITALIAN, pitch)}", color = TextMain)
                        Slider(
                            value = pitch,
                            onValueChange = { pitch = it },
                            onValueChangeFinished = { prefs.ttsPitch = pitch; onPrefsChanged() },
                            valueRange = 0.5f..1.5f
                        )
                    }
                }
                item {
                    SwitchRow(
                        "Modalità conversazione",
                        "Dopo la risposta riascolta in automatico (richiede risposte parlate)",
                        conversation
                    ) { conversation = it; prefs.conversationMode = it }
                }
                item {
                    SwitchRow(
                        "Ascolto rapido all'avvio",
                        "Il microfono parte appena apre l'app",
                        listenOnLaunch
                    ) { listenOnLaunch = it; prefs.listenOnLaunch = it }
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (ttsProblem != null) Text(ttsProblem, color = TextDim, fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = onTestVoice) { Text("Prova voce") }
                            OutlinedButton(onClick = {
                                tryStart(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA))
                            }) { Text("Voce italiana") }
                            OutlinedButton(onClick = {
                                tryStart(Intent("com.android.settings.TTS_SETTINGS"))
                            }) { Text("Sintesi vocale") }
                        }
                    }
                }

                // ---------------- IA
                item { HorizontalDivider(color = Cyan.copy(alpha = 0.2f)) }
                item { SectionTitle("Intelligenza artificiale (opzionale)") }
                item {
                    Text(
                        "Per i comandi non di sistema. API compatibile con /v1/chat/completions. " +
                            "Senza chiave, i comandi locali funzionano comunque.",
                        color = TextDim,
                        fontSize = 13.sp
                    )
                }
                item {
                    OutlinedTextField(
                        value = endpoint,
                        onValueChange = { endpoint = it; prefs.aiEndpoint = it },
                        label = { Text("Endpoint") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = key,
                        onValueChange = { key = it; prefs.aiKey = it },
                        label = { Text("Chiave API") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it; prefs.aiModel = it },
                        label = { Text("Modello") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // ---------------- note
                item { HorizontalDivider(color = Cyan.copy(alpha = 0.2f)) }
                item { SectionTitle("Note") }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Note salvate: $noteCount", color = TextMain, modifier = Modifier.weight(1f))
                        TextButton(onClick = { prefs.notes = emptyList(); noteCount = 0 }) {
                            Text("Cancella tutte")
                        }
                    }
                }

                // ---------------- app riconosciute
                item { HorizontalDivider(color = Cyan.copy(alpha = 0.2f)) }
                item { SectionTitle("App riconosciute (${apps.size})") }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = filter,
                            onValueChange = { filter = it },
                            label = { Text("Cerca app") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        OutlinedButton(onClick = onRefreshApps) { Text("Aggiorna") }
                    }
                }
                items(filtered, key = { it.packageName + "/" + it.activity }) { a ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(a.label, color = TextMain, fontSize = 16.sp)
                            Text(a.packageName, color = TextDim, fontSize = 11.sp)
                        }
                        TextButton(onClick = { onOpenApp(a) }) { Text("Prova") }
                    }
                }
                item { Spacer(Modifier.padding(bottom = 24.dp)) }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = TextMain, fontSize = 16.sp)
            Text(subtitle, color = TextDim, fontSize = 12.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
