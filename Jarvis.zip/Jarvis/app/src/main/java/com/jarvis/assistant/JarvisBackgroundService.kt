package com.jarvis.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class JarvisBackgroundService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var isRunning = false
    private var isPausedForApp = false
    private var isListeningNow = false

    private val restartRunnable = Runnable {
        if (isRunning && !isPausedForApp) {
            startWakeWordListening()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopWakeService()
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> {
                isPausedForApp = true
                stopRecognizerNow()
                return START_STICKY
            }
            ACTION_RESUME -> {
                isPausedForApp = false
                if (isRunning) {
                    scheduleRestart(250L)
                }
                return START_STICKY
            }
            else -> {
                val notification = buildNotification()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    startForeground(
                        NOTIFICATION_ID,
                        notification,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    )
                } else {
                    startForeground(NOTIFICATION_ID, notification)
                }
                isRunning = true
                if (!isPausedForApp) {
                    scheduleRestart(200L)
                }
                return START_STICKY
            }
        }
    }

    private fun stopWakeService() {
        isRunning = false
        isPausedForApp = false
        main.removeCallbacks(restartRunnable)
        stopRecognizerNow()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun scheduleRestart(delayMs: Long) {
        main.removeCallbacks(restartRunnable)
        if (isRunning && !isPausedForApp) {
            main.postDelayed(restartRunnable, delayMs)
        }
    }

    private fun stopRecognizerNow() {
        isListeningNow = false
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (_: Exception) {
        }
        recognizer = null
    }

    private fun hasMicPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun startWakeWordListening() {
        if (!isRunning || isPausedForApp || isListeningNow) return
        if (!hasMicPermission() || !SpeechRecognizer.isRecognitionAvailable(this)) {
            scheduleRestart(3000L)
            return
        }

        stopRecognizerNow()

        val r = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(wakeListener)
            recognizer = it
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "it-IT")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }

        isListeningNow = true
        try {
            r.startListening(intent)
        } catch (_: Exception) {
            isListeningNow = false
            scheduleRestart(1500L)
        }
    }

    private fun checkWakeWord(rawText: String?) {
        val text = rawText?.lowercase()?.trim().orEmpty()
        if (text.isEmpty()) return

        val triggered = text.contains("hey jarvis") ||
            text.contains("ei jarvis") ||
            text.contains("ehi jarvis") ||
            Regex("""\bjarvis\b""").containsMatchIn(text)

        if (triggered) {
            val afterWake = text.substringAfter("jarvis", missingDelimiterValue = "").trim()
            stopRecognizerNow()

            val launchIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP
                )
                action = ACTION_WAKE_WORD_DETECTED
                putExtra(EXTRA_WAKE_COMMAND, afterWake)
            }
            startActivity(launchIntent)
        }
    }

    private val wakeListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            isListeningNow = true
        }

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {}

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            isListeningNow = false
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.joinToString(" ")
            checkWakeWord(partial)
        }

        override fun onResults(results: Bundle?) {
            isListeningNow = false
            val full = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.joinToString(" ")
            checkWakeWord(full)
            scheduleRestart(250L)
        }

        override fun onError(error: Int) {
            isListeningNow = false
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> scheduleRestart(3000L)
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                SpeechRecognizer.ERROR_SERVER,
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> scheduleRestart(1200L)
                else -> scheduleRestart(300L)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Ascolto Hey Jarvis",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Mantiene attivo il rilevamento vocale di Hey Jarvis in background"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, JarvisBackgroundService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStop = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("J.A.R.V.I.S. in ascolto")
            .setContentText("Di' \"Hey Jarvis\" per attivare l'assistente")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingOpen)
            .addAction(0, "Ferma", pendingStop)
            .build()
    }

    override fun onDestroy() {
        isRunning = false
        main.removeCallbacks(restartRunnable)
        stopRecognizerNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "jarvis_wake_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.jarvis.assistant.action.START_WAKE"
        const val ACTION_STOP = "com.jarvis.assistant.action.STOP_WAKE"
        const val ACTION_PAUSE = "com.jarvis.assistant.action.PAUSE_WAKE"
        const val ACTION_RESUME = "com.jarvis.assistant.action.RESUME_WAKE"

        const val ACTION_WAKE_WORD_DETECTED = "com.jarvis.assistant.action.WAKE_WORD_DETECTED"
        const val EXTRA_WAKE_COMMAND = "extra_wake_command"

        fun start(context: Context) {
            val intent = Intent(context, JarvisBackgroundService::class.java).apply {
                action = ACTION_START
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, JarvisBackgroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun pauseForApp(context: Context) {
            val intent = Intent(context, JarvisBackgroundService::class.java).apply {
                action = ACTION_PAUSE
            }
            try {
                context.startService(intent)
            } catch (_: Exception) {
            }
        }

        fun resumeAfterApp(context: Context) {
            val intent = Intent(context, JarvisBackgroundService::class.java).apply {
                action = ACTION_RESUME
            }
            try {
                context.startService(intent)
            } catch (_: Exception) {
            }
        }
    }
}