package com.jarvis.assistant

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ChatMessage(val id: Long, val fromUser: Boolean, val text: String)

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    val prefs = Prefs(application)
    val voice = VoiceManager(application, prefs)
    private val ai = AiClient(prefs)
    private val executor = CommandExecutor(application, prefs, ai)

    val messages = mutableStateListOf<ChatMessage>()

    var thinking by mutableStateOf(false)
        private set

    var status by mutableStateOf(IDLE_STATUS)
        private set

    var apps by mutableStateOf<List<AppEntry>>(emptyList())
        private set

    private var nextId = 0L
    private var lastWasVoice = false

    init {
        voice.onFinalText = { handleInput(it, fromVoice = true) }
        voice.onVoiceError = { status = it }
        voice.onSpeechDone = {
            if (prefs.conversationMode && lastWasVoice && !thinking) voice.startListening()
        }
        addJarvis("${greetingWord()}. Sono J.A.R.V.I.S. Come posso esserle utile?")
        refreshApps()
    }

    private fun addJarvis(text: String) {
        messages += ChatMessage(nextId++, false, text)
    }

    fun handleInput(text: String, fromVoice: Boolean = false) {
        val t = text.trim()
        if (t.isEmpty()) return
        lastWasVoice = fromVoice
        status = IDLE_STATUS

        val history = messages.takeLast(10).map { (if (it.fromUser) "user" else "assistant") to it.text }
        messages += ChatMessage(nextId++, true, t)

        viewModelScope.launch {
            thinking = true
            val out = try {
                executor.execute(t, history)
            } catch (e: Exception) {
                Outcome("Si è verificato un errore imprevisto.")
            }
            thinking = false

            when (out.action) {
                UiAction.CLEAR_CHAT -> messages.clear()
                UiAction.STOP_SPEAKING -> {
                    voice.stopSpeaking()
                    lastWasVoice = false
                    return@launch
                }
                UiAction.NONE -> Unit
            }

            if (out.reply.isNotBlank()) {
                addJarvis(out.reply)
                if (prefs.speakReplies) {
                    voice.speak(out.reply)
                } else if (prefs.conversationMode && fromVoice) {
                    voice.startListening()
                }
            }
        }
    }

    fun toggleListen() {
        status = IDLE_STATUS
        if (voice.state.value == VoiceState.LISTENING) voice.stopListening() else voice.startListening()
    }

    fun listen() {
        status = IDLE_STATUS
        voice.startListening()
    }

    fun showStatus(s: String) {
        status = s
    }

    fun clearChat() {
        messages.clear()
    }

    fun testVoice() {
        voice.applyPrefs()
        voice.speak("Sistemi operativi. Sono a sua disposizione.")
    }

    fun applyVoicePrefs() = voice.applyPrefs()

    fun refreshApps() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.Default) { executor.installedApps(force = true) }
            apps = list
        }
    }

    fun openApp(entry: AppEntry) {
        executor.launch(entry)
    }

    fun onAppStopped() {
        voice.stopListening()
    }

    override fun onCleared() {
        voice.shutdown()
        super.onCleared()
    }

    companion object {
        const val IDLE_STATUS = "Tocchi il microfono o scriva un comando"
    }
}
