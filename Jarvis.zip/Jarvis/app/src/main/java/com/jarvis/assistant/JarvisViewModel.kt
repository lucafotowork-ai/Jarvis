package com.jarvis.assistant

import android.speech.tts.TextToSpeech
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class JarvisMessage(
    val text: String,
    val fromUser: Boolean
)

class JarvisViewModel : ViewModel() {

    private val conversationEngine = JarvisConversationEngine()

    private val _messages = MutableStateFlow(
        listOf(
            JarvisMessage(
                text = "Sistemi online. Di' \"Hey Jarvis\" o scrivimi qui sotto.",
                fromUser = false
            )
        )
    )
    val messages: StateFlow<List<JarvisMessage>> = _messages.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    fun setListening(listening: Boolean) {
        _isListening.value = listening
    }

    fun sendUserMessage(rawText: String, tts: TextToSpeech? = null, speakReply: Boolean = false) {
        val cleaned = rawText.trim()
        if (cleaned.isEmpty()) return

        val replyText = conversationEngine.reply(cleaned)

        _messages.update { current ->
            current +
                JarvisMessage(text = cleaned, fromUser = true) +
                JarvisMessage(text = replyText, fromUser = false)
        }

        if (speakReply && tts != null) {
            tts.speak(replyText, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply_${System.currentTimeMillis()}")
        }
    }

    fun clearConversation() {
        conversationEngine.clearHistory()
        _messages.value = listOf(
            JarvisMessage(
                text = "Conversazione azzerata. Come posso aiutarti?",
                fromUser = false
            )
        )
    }
}