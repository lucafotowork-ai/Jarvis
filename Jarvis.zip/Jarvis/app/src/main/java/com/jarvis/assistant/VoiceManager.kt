package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

enum class VoiceState { IDLE, LISTENING, PROCESSING, SPEAKING }

/**
 * Gestisce SpeechRecognizer (it-IT) e TextToSpeech (Locale.ITALIAN).
 * Nessun servizio in background: il microfono è attivo solo durante una sessione di ascolto.
 */
class VoiceManager(context: Context, private val prefs: Prefs) {

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    private val _state = MutableStateFlow(VoiceState.IDLE)
    val state: StateFlow<VoiceState> = _state

    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial

    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level

    /** Testo finale riconosciuto (thread principale). */
    var onFinalText: ((String) -> Unit)? = null

    /** Errore di riconoscimento da mostrare come stato (thread principale). */
    var onVoiceError: ((String) -> Unit)? = null

    /** La sintesi ha finito di parlare normalmente (thread principale). */
    var onSpeechDone: (() -> Unit)? = null

    /** Descrizione di un eventuale problema con la voce italiana. */
    var ttsProblem: String? = null
        private set

    init {
        initTts()
    }

    // ------------------------------------------------------------------ TTS

    private fun initTts() {
        tts = TextToSpeech(app) { status ->
            val engine = tts
            if (status != TextToSpeech.SUCCESS || engine == null) {
                ttsProblem = "Motore di sintesi vocale non disponibile."
                return@TextToSpeech
            }
            val r = engine.setLanguage(Locale.ITALIAN)
            ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) {
                ttsProblem = "Voce italiana non installata: installi i dati vocali italiani."
            }
            engine.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _state.value = VoiceState.SPEAKING
                }

                override fun onDone(utteranceId: String?) {
                    _state.value = VoiceState.IDLE
                    main.post { onSpeechDone?.invoke() }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _state.value = VoiceState.IDLE
                }

                override fun onStop(utteranceId: String?, interrupted: Boolean) {
                    if (_state.value == VoiceState.SPEAKING) _state.value = VoiceState.IDLE
                }
            })
            applyPrefs()
        }
    }

    /** Riapplica velocità e tono salvati nelle impostazioni. */
    fun applyPrefs() {
        tts?.setSpeechRate(prefs.ttsRate)
        tts?.setPitch(prefs.ttsPitch)
    }

    fun speak(text: String) {
        val engine = tts ?: return
        if (!ttsReady) return
        val clean = text.replace(Regex("[*_#`>]"), "").trim()
        if (clean.isEmpty()) return
        val limited = clean.take(TextToSpeech.getMaxSpeechInputLength() - 1)
        engine.speak(limited, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utterance")
    }

    fun stopSpeaking() {
        tts?.stop()
        if (_state.value == VoiceState.SPEAKING) _state.value = VoiceState.IDLE
    }

    // ------------------------------------------------------------------ STT

    fun startListening() {
        main.post { doStartListening() }
    }

    fun stopListening() {
        main.post {
            val st = _state.value
            if (st == VoiceState.LISTENING) {
                recognizer?.stopListening()   // elabora quanto detto finora
            } else if (st == VoiceState.PROCESSING) {
                recognizer?.cancel()
                _state.value = VoiceState.IDLE
            }
        }
    }

    private fun doStartListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            onVoiceError?.invoke("Riconoscimento vocale non disponibile: serve l'app Google.")
            return
        }
        if (_state.value == VoiceState.LISTENING) return
        stopSpeaking() // evita che il microfono senta la voce di Jarvis

        val r = recognizer ?: SpeechRecognizer.createSpeechRecognizer(app).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }
        _partial.value = ""
        _level.value = 0f

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "it-IT")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
        }
        _state.value = VoiceState.LISTENING
        r.startListening(intent)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            _state.value = VoiceState.LISTENING
        }

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            _level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            _state.value = VoiceState.PROCESSING
            _level.value = 0f
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!t.isNullOrBlank()) _partial.value = t
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
                .trim()
            _partial.value = ""
            _level.value = 0f
            _state.value = VoiceState.IDLE
            if (text.isEmpty()) {
                onVoiceError?.invoke("Non ho sentito nulla.")
            } else {
                onFinalText?.invoke(text)
            }
        }

        override fun onError(error: Int) {
            _partial.value = ""
            _level.value = 0f
            _state.value = VoiceState.IDLE
            when (error) {
                SpeechRecognizer.ERROR_CLIENT -> Unit // annullamento volontario
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    onVoiceError?.invoke("Non ho sentito nulla.")
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    onVoiceError?.invoke("Serve il permesso del microfono.")
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER ->
                    onVoiceError?.invoke("Riconoscimento non raggiungibile. Controlli la connessione.")
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    recognizer?.destroy()
                    recognizer = null
                    onVoiceError?.invoke("Riconoscitore occupato, riprovi.")
                }
                else -> onVoiceError?.invoke("Errore di riconoscimento vocale ($error).")
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    // ------------------------------------------------------------------ ciclo di vita

    fun shutdown() {
        main.post {
            recognizer?.destroy()
            recognizer = null
        }
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
