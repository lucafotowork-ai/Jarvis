package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Connettore opzionale verso un LLM tramite API compatibile con /v1/chat/completions
 * (OpenAI, OpenRouter, Groq, ecc.). Usa solo HttpURLConnection: nessuna libreria extra.
 * Viene chiamato SOLO quando il parser locale non riconosce un comando di sistema.
 */
class AiClient(private val prefs: Prefs) {

    fun isConfigured(): Boolean = prefs.aiKey.isNotBlank() && prefs.aiEndpoint.isNotBlank()

    /** @param history coppie (ruolo, testo) con ruolo "user" o "assistant". */
    suspend fun chat(user: String, history: List<Pair<String, String>>): String =
        withContext(Dispatchers.IO) {
            val msgs = JSONArray()
            msgs.put(JSONObject().put("role", "system").put("content", SYSTEM_PROMPT))
            history.takeLast(8).forEach { (role, content) ->
                msgs.put(JSONObject().put("role", role).put("content", content))
            }
            msgs.put(JSONObject().put("role", "user").put("content", user))

            val body = JSONObject()
                .put("model", prefs.aiModel)
                .put("messages", msgs)

            val conn = (URL(prefs.aiEndpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 25_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("Authorization", "Bearer ${prefs.aiKey}")
            }
            try {
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) throw IOException("errore $code")
                JSONObject(text)
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                    .trim()
            } finally {
                conn.disconnect()
            }
        }

    private companion object {
        const val SYSTEM_PROMPT =
            "Sei J.A.R.V.I.S., un assistente vocale calmo, elegante e diretto. " +
                "Rispondi sempre in italiano, con al massimo due frasi brevi, " +
                "dando del lei all'utente. Il testo verrà letto ad alta voce: " +
                "niente markdown, elenchi, emoji, URL o simboli; scrivi i numeri in modo naturale. " +
                "Se non sai qualcosa, dillo con semplicità."
    }
}
