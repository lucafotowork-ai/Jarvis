package com.jarvis.assistant

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF00E5FF)
val Bg = Color(0xFF03070D)
val PanelBg = Color(0xFF0A1622)
val UserBubble = Color(0xFF12303F)
val TextMain = Color(0xFFD6F4FF)
val TextDim = Color(0xFF7FA6B8)

private val JarvisColors = darkColorScheme(
    primary = Cyan,
    onPrimary = Color.Black,
    secondary = Color(0xFF4FC3F7),
    background = Bg,
    onBackground = TextMain,
    surface = PanelBg,
    onSurface = TextMain,
    surfaceVariant = Color(0xFF0F2030),
    onSurfaceVariant = TextDim,
    outline = Color(0x6600E5FF)
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = JarvisColors, content = content)
}
