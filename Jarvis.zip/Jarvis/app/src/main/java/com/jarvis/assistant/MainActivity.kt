package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val vm: JarvisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val firstLaunch = savedInstanceState == null
        setContent {
            JarvisTheme {
                JarvisApp(vm, autoListen = firstLaunch && vm.prefs.listenOnLaunch)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Nessun ascolto in background: il microfono si spegne quando l'app esce dal primo piano.
        vm.onAppStopped()
    }
}

@Composable
fun JarvisApp(vm: JarvisViewModel, autoListen: Boolean) {
    val context = LocalContext.current
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var hasMic by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMic = granted
        if (granted) vm.listen()
        else vm.showStatus("Permesso microfono negato. Può comunque scrivere i comandi.")
    }

    val onMic: () -> Unit = {
        if (hasMic) vm.toggleListen() else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(Unit) {
        if (autoListen && hasMic) vm.listen()
    }

    BackHandler(enabled = showSettings) { showSettings = false }

    if (showSettings) {
        SettingsScreen(
            prefs = vm.prefs,
            apps = vm.apps,
            ttsProblem = vm.voice.ttsProblem,
            onBack = { showSettings = false },
            onPrefsChanged = vm::applyVoicePrefs,
            onTestVoice = vm::testVoice,
            onOpenApp = vm::openApp,
            onRefreshApps = vm::refreshApps
        )
    } else {
        MainScreen(vm, onMic = onMic, onSettings = { showSettings = true })
    }
}

// ---------------------------------------------------------------------- schermata principale

@Composable
fun MainScreen(vm: JarvisViewModel, onMic: () -> Unit, onSettings: () -> Unit) {
    val state by vm.voice.state.collectAsState()
    val partial by vm.voice.partial.collectAsState()
    val levelState = vm.voice.level.collectAsState()

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF06111C), Bg)))
            .safeDrawingPadding()
    ) {
        val wide = maxWidth > 720.dp && maxWidth > maxHeight

        if (wide) {
            // Landscape / schermo largo: HUD a sinistra, chat a destra.
            Row(Modifier.fillMaxSize()) {
                Column(Modifier.weight(0.42f).fillMaxHeight()) {
                    TopBar(onClear = vm::clearChat, onSettings = onSettings)
                    HudPanel(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        orbSize = 300.dp,
                        state = state,
                        thinking = vm.thinking,
                        partial = partial,
                        status = vm.status,
                        level = levelState,
                        onMic = onMic
                    )
                }
                ChatPanel(Modifier.weight(0.58f).fillMaxHeight(), vm)
            }
        } else {
            // Portrait: HUD compatto sopra, chat sotto.
            Column(Modifier.fillMaxSize()) {
                TopBar(onClear = vm::clearChat, onSettings = onSettings)
                HudPanel(
                    modifier = Modifier.fillMaxWidth().height(270.dp),
                    orbSize = 170.dp,
                    state = state,
                    thinking = vm.thinking,
                    partial = partial,
                    status = vm.status,
                    level = levelState,
                    onMic = onMic
                )
                ChatPanel(Modifier.weight(1f).fillMaxWidth(), vm)
            }
        }
    }
}

@Composable
private fun TopBar(onClear: () -> Unit, onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "J.A.R.V.I.S.",
            color = Cyan,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            letterSpacing = 4.sp
        )
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onClear) {
            Icon(Icons.Default.Delete, contentDescription = "Pulisci la chat", tint = Cyan)
        }
        IconButton(onClick = onSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Impostazioni", tint = Cyan)
        }
    }
}

@Composable
private fun HudPanel(
    modifier: Modifier,
    orbSize: Dp,
    state: VoiceState,
    thinking: Boolean,
    partial: String,
    status: String,
    level: State<Float>,
    onMic: () -> Unit
) {
    val label = when {
        state == VoiceState.LISTENING -> "In ascolto…"
        thinking || state == VoiceState.PROCESSING -> "Elaboro…"
        state == VoiceState.SPEAKING -> "Sto parlando…"
        else -> status
    }
    Column(
        modifier.padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(orbSize), contentAlignment = Alignment.Center) {
            Orb(Modifier.fillMaxSize(), state, thinking, level)
            MicButton(listening = state == VoiceState.LISTENING, onClick = onMic)
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Cyan, fontSize = 14.sp, textAlign = TextAlign.Center)
        if (partial.isNotEmpty()) {
            Text(
                partial,
                color = TextDim,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                maxLines = 2,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

/** Anelli HUD. Si anima solo quando Jarvis è attivo: a riposo nessun frame viene ridisegnato. */
@Composable
private fun Orb(modifier: Modifier, state: VoiceState, thinking: Boolean, level: State<Float>) {
    val active = state != VoiceState.IDLE || thinking
    val transition = rememberInfiniteTransition(label = "orb")
    val rot by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(12000, easing = LinearEasing)),
        label = "rot"
    )
    val pulse by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2f
        val lv = if (state == VoiceState.LISTENING) level.value else 0f
        val breathe = if (active) pulse else 0f
        val angle = if (active) rot else 0f

        // alone
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Cyan.copy(alpha = 0.18f + 0.25f * lv), Color.Transparent),
                center = c,
                radius = r * 0.85f
            ),
            radius = r * 0.85f,
            center = c
        )
        // anello esterno pulsante
        drawCircle(
            color = Cyan.copy(alpha = 0.12f + 0.15f * breathe),
            radius = r * (0.93f + 0.04f * breathe + 0.06f * lv),
            center = c,
            style = Stroke(2.dp.toPx())
        )
        // archi rotanti
        rotate(angle, pivot = c) {
            for (i in 0 until 3) {
                drawArc(
                    color = Cyan.copy(alpha = 0.85f - i * 0.2f),
                    startAngle = i * 120f,
                    sweepAngle = 70f,
                    useCenter = false,
                    topLeft = Offset(c.x - r * 0.78f, c.y - r * 0.78f),
                    size = Size(r * 1.56f, r * 1.56f),
                    style = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
        // anello interno tratteggiato in controrotazione
        rotate(-angle * 1.5f, pivot = c) {
            drawCircle(
                color = Cyan.copy(alpha = 0.45f),
                radius = r * 0.62f,
                center = c,
                style = Stroke(
                    1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 14f), 0f)
                )
            )
        }
    }
}

@Composable
private fun MicButton(listening: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(84.dp)
            .clip(CircleShape)
            .background(if (listening) Cyan else Color(0xFF0B1A26))
            .border(2.dp, Cyan, CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = "Microfono: tocca per parlare" },
        contentAlignment = Alignment.Center
    ) {
        MicIcon(color = if (listening) Color.Black else Cyan, modifier = Modifier.size(38.dp))
    }
}

/** Icona microfono disegnata a mano, per non dipendere dal pacchetto icone esteso (pesante). */
@Composable
private fun MicIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val sw = w * 0.09f
        drawRoundRect(
            color = color,
            topLeft = Offset(w * 0.35f, h * 0.05f),
            size = Size(w * 0.30f, h * 0.52f),
            cornerRadius = CornerRadius(w * 0.15f)
        )
        drawArc(
            color = color,
            startAngle = 0f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(w * 0.20f, h * 0.22f),
            size = Size(w * 0.60f, h * 0.50f),
            style = Stroke(sw, cap = StrokeCap.Round)
        )
        drawLine(color, Offset(w * 0.5f, h * 0.72f), Offset(w * 0.5f, h * 0.92f), sw, StrokeCap.Round)
        drawLine(color, Offset(w * 0.33f, h * 0.93f), Offset(w * 0.67f, h * 0.93f), sw, StrokeCap.Round)
    }
}

// ---------------------------------------------------------------------- chat

@Composable
private fun ChatPanel(modifier: Modifier, vm: JarvisViewModel) {
    val listState = rememberLazyListState()
    val messages = vm.messages
    var input by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    val submit = {
        vm.handleInput(input)
        input = ""
    }

    Column(modifier.padding(horizontal = 16.dp)) {
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(messages, key = { it.id }) { Bubble(it) }
        }
        Row(
            Modifier.fillMaxWidth().padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Scriva un comando…") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { submit() })
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = { submit() }) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Invia", tint = Cyan)
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    val shape = if (m.fromUser) {
        RoundedCornerShape(16.dp, 16.dp, 4.dp, 16.dp)
    } else {
        RoundedCornerShape(4.dp, 16.dp, 16.dp, 16.dp)
    }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            Modifier
                .widthIn(max = 560.dp)
                .clip(shape)
                .background(if (m.fromUser) UserBubble else PanelBg)
                .border(1.dp, Cyan.copy(alpha = if (m.fromUser) 0.15f else 0.40f), shape)
                .padding(12.dp)
        ) {
            if (!m.fromUser) {
                Text(
                    "J.A.R.V.I.S.",
                    color = Cyan,
                    fontSize = 10.sp,
                    letterSpacing = 2.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Text(m.text, color = TextMain, fontSize = 16.sp)
        }
    }
}
