package com.jarvis.assistant

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ConversationTurn(
    val fromUser: Boolean,
    val text: String
)

class JarvisConversationEngine(
    private val maxHistoryTurns: Int = 12
) {
    private val history = ArrayDeque<ConversationTurn>()
    private var lastTopic: String? = null

    fun clearHistory() {
        history.clear()
        lastTopic = null
    }

    fun getHistory(): List<ConversationTurn> = history.toList()

    fun reply(rawInput: String): String {
        val cleaned = rawInput.trim()
        if (cleaned.isEmpty()) {
            return "Non ho sentito nulla. Dimmi pure come posso aiutarti."
        }

        recordTurn(fromUser = true, text = cleaned)

        val q = cleaned.lowercase(Locale.ITALIAN)
        val response = generateResponse(q, cleaned)

        recordTurn(fromUser = false, text = response)
        return response
    }

    private fun recordTurn(fromUser: Boolean, text: String) {
        history.addLast(ConversationTurn(fromUser = fromUser, text = text))
        while (history.size > maxHistoryTurns) {
            history.removeFirst()
        }
    }

    private fun generateResponse(q: String, original: String): String {
        if (
            q.contains("che ora") ||
            q.contains("che ore") ||
            q.contains("l'ora") ||
            q.contains("ora è") ||
            q.contains("ora e")
        ) {
            lastTopic = "time"
            val timeFormat = SimpleDateFormat("HH:mm", Locale.ITALIAN)
            return "Sono le ${timeFormat.format(Date())}."
        }

        if (
            q.contains("che giorno") ||
            q.contains("che data") ||
            q.contains("oggi è") ||
            q.contains("oggi e")
        ) {
            lastTopic = "date"
            val dateFormat = SimpleDateFormat("EEEE d MMMM yyyy", Locale.ITALIAN)
            return "Oggi è ${dateFormat.format(Date())}."
        }

        if (
            q == "ciao" ||
            q.startsWith("ciao ") ||
            q.startsWith("ehi") ||
            q.startsWith("hey") ||
            q.contains("buongiorno") ||
            q.contains("buonasera") ||
            q.contains("buonanotte")
        ) {
            lastTopic = "greeting"
            return "Ciao! Sono J.A.R.V.I.S. Puoi chiedermi l'ora, la data o fare due chiacchiere con me."
        }

        if (q.contains("come stai") || q.contains("tutto bene")) {
            lastTopic = "status"
            return "Tutto operativo e in ascolto. Tu come stai?"
        }

        if (q.contains("chi sei") || q.contains("cosa sai fare") || q.contains("aiuto")) {
            lastTopic = "help"
            return "Sono J.A.R.V.I.S., il tuo assistente su tablet. Posso dirti l'ora e la data, rispondere a domande semplici e seguire il filo della nostra conversazione."
        }

        if (q.contains("grazie") || q.contains("gentile")) {
            return "Figurati, sempre a tua disposizione."
        }

        if (q == "basta" || q == "chiudi" || q.contains("a dopo") || q.contains("ci sentiamo")) {
            return "Va bene, resto in attesa del prossimo comando."
        }

        if (q.startsWith("e ") || q.contains("ancora")) {
            if (lastTopic == "time") {
                val timeFormat = SimpleDateFormat("HH:mm", Locale.ITALIAN)
                return "L'ora attuale è sempre ${timeFormat.format(Date())}."
            }
            if (lastTopic == "date") {
                val dateFormat = SimpleDateFormat("EEEE d MMMM yyyy", Locale.ITALIAN)
                return "La data di oggi resta ${dateFormat.format(Date())}."
            }
        }

        val previousUserMessage = history
            .dropLast(1)
            .lastOrNull { it.fromUser }
            ?.text

        return if (previousUserMessage != null && previousUserMessage.lowercase(Locale.ITALIAN) != q) {
            "Ho annotato \"$original\" (dopo aver parlato di \"$previousUserMessage\"). Al momento uso una modalità di conversazione base locale: chiedimi pure l'ora, la data o dimmi cosa vuoi fare."
        } else {
            "Ho ricevuto \"$original\". Posso dirti l'ora, la data o chiacchierare con te in modalità base; dimmi pure cosa ti serve."
        }
    }
}