package com.jarvis.assistant

import android.content.Context
import org.json.JSONArray

/** Preferenze locali dell'app (SharedPreferences: nessuna dipendenza extra, avvio istantaneo). */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

    var ttsRate: Float
        get() = sp.getFloat("tts_rate", 1.0f)
        set(v) { sp.edit().putFloat("tts_rate", v).apply() }

    var ttsPitch: Float
        get() = sp.getFloat("tts_pitch", 0.9f)
        set(v) { sp.edit().putFloat("tts_pitch", v).apply() }

    /** Se false Jarvis risponde solo a testo. */
    var speakReplies: Boolean
        get() = sp.getBoolean("speak_replies", true)
        set(v) { sp.edit().putBoolean("speak_replies", v).apply() }

    /** Dopo una risposta vocale rimette subito il microfono in ascolto. */
    var conversationMode: Boolean
        get() = sp.getBoolean("conversation_mode", false)
        set(v) { sp.edit().putBoolean("conversation_mode", v).apply() }

    /** Ascolto rapido: parte il microfono appena si apre l'app. */
    var listenOnLaunch: Boolean
        get() = sp.getBoolean("listen_on_launch", false)
        set(v) { sp.edit().putBoolean("listen_on_launch", v).apply() }

    // --- Connettore IA opzionale (API compatibile con /v1/chat/completions) ---
    var aiEndpoint: String
        get() = sp.getString("ai_endpoint", "https://api.openai.com/v1/chat/completions").orEmpty()
        set(v) { sp.edit().putString("ai_endpoint", v.trim()).apply() }

    var aiKey: String
        get() = sp.getString("ai_key", "").orEmpty()
        set(v) { sp.edit().putString("ai_key", v.trim()).apply() }

    var aiModel: String
        get() = sp.getString("ai_model", "gpt-4o-mini").orEmpty()
        set(v) { sp.edit().putString("ai_model", v.trim()).apply() }

    // --- Note / promemoria locali ---
    var notes: List<String>
        get() {
            val arr = JSONArray(sp.getString("notes", "[]"))
            return List(arr.length()) { arr.getString(it) }
        }
        set(v) { sp.edit().putString("notes", JSONArray(v).toString()).apply() }
}
