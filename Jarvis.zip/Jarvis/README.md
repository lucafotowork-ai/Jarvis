# J.A.R.V.I.S. per Redmi Pad Pro

Assistente vocale nativo Android (Kotlin + Jetpack Compose), interamente in italiano.
Ascolta (it-IT), risponde a voce (TTS italiano) ed esegue azioni reali: apre le app installate,
dice ora e data, prende note. Per le conversazioni libere può usare un LLM (opzionale).

## Architettura

```
UI (MainActivity.kt, SettingsScreen.kt)      Compose: HUD animato, chat, impostazioni, layout responsive
   │
JarvisViewModel.kt                            stato della chat, orchestrazione, ciclo di vita
   ├── VoiceManager.kt                        SpeechRecognizer (it-IT) + TextToSpeech (Locale.ITALIAN)
   └── CommandExecutor.kt                     parser locale -> PackageManager + Intent, ora/data/note/stop
          └── AiClient.kt                     hook LLM, solo se il parser locale non riconosce il comando
Prefs.kt                                      SharedPreferences (voce, IA, note)
```

Priorità dei comandi: **parser locale (zero latenza) → IA (solo se configurata)**.

## Comandi supportati

- «Apri YouTube / Chrome / Impostazioni / Galleria / Spotify / [nome app]» (anche «avvia», «lancia»)
- «Che ore sono?», «Che giorno è oggi?»
- «Imposta un promemoria…», «Ricordami di…», «Prendi nota…», «Leggi le note», «Cancella le note»
- «Pulisci la chat», «Smetti di parlare» / «Zitto» / «Basta»
- Se il nome è ambiguo: «Intende Spotify o YouTube Music?» (risponda con il nome o «il primo»)
- Scorciatoie di sistema: Impostazioni, Wi-Fi, Bluetooth, schermo

## Compilare e installare

1. Android Studio (Ladybug o successivo) → *Open* → cartella `Jarvis`. Accetti il download di Gradle
   e degli SDK (compileSdk 35); se propone un aggiornamento di AGP/Gradle, lo accetti.
2. Sul Redmi Pad Pro: *Impostazioni → Info sul tablet* → tocchi 7 volte «Versione OS» →
   *Impostazioni aggiuntive → Opzioni sviluppatore* → attivi **Debug USB** (e **Installa via USB**).
3. Colleghi il tablet via USB, accetti la richiesta di debug, scelga il dispositivo e prema ▶ *Run*.
4. APK da installare a mano: *Build → Build Bundle(s)/APK(s) → Build APK(s)* (debug), oppure da terminale
   `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`
   (firmato con la chiave di debug, quindi installabile subito: `adb install -r app-release.apk`).

## Testare

1. Al primo tocco sul microfono concedere il permesso **Microfono**.
2. Provi: «Apri Impostazioni», «Apri YouTube», «Che ore sono?», «Ricordami di comprare il latte», «Leggi le note».
3. *Impostazioni → App riconosciute* mostra le app che Jarvis vede, con pulsante **Prova**.

## Risoluzione problemi (Redmi / HyperOS)

- **Riconoscimento vocale non disponibile**: serve l'app **Google** (con il riconoscimento vocale) attiva
  e aggiornata. Per l'italiano offline: Google → Impostazioni → Voce → Riconoscimento vocale offline.
- **Nessuna voce italiana**: *Impostazioni → Voce italiana* (o Impostazioni di sistema → Sintesi vocale)
  e installi i dati vocali italiani del motore Google.
- **Un'app non viene trovata**: premere *Aggiorna* nelle impostazioni; verifichi il nome mostrato nell'elenco.
- **Risposta tagliata dopo l'apertura di un'app**: è normale, la voce prosegue mentre l'altra app si apre.
- **Batteria/avvio in background**: MIUI/HyperOS può limitare le app; qui non serve, perché Jarvis non ha servizi
  in background (il microfono si spegne quando l'app esce dal primo piano).

## Note tecniche

- minSdk 29, target 35. `<queries>` con intent LAUNCHER al posto del permesso `QUERY_ALL_PACKAGES`.
- Connettore IA: endpoint HTTPS compatibile OpenAI. La chiave è salvata in SharedPreferences non cifrate
  (`allowBackup=false`): per uso personale va bene, per distribuzione usare Android Keystore.
- Nessuna libreria di rete o di icone aggiuntiva: APK piccolo, R8 e shrink risorse attivi in release.
